
export default function Home(){
return (
<main style={{background:'#111',color:'#fff',minHeight:'100vh'}}>
<header style={{padding:'24px',display:'flex',justifyContent:'space-between'}}>
<h2 style={{color:'#e11d2e'}}>DT28 Câmbios Automáticos</h2>
<nav>Home | Serviços | Contato</nav>
</header>
<section style={{padding:'80px 24px',textAlign:'center'}}>
<h1 style={{fontSize:'48px'}}>Especialistas em Câmbios Automáticos</h1>
<p>Diagnóstico • Troca de Óleo • Mecatrônica • Conversor de Torque</p>
<a href="https://wa.me/5544998034786" style={{background:'#e11d2e',padding:'16px 24px',color:'#fff',textDecoration:'none',borderRadius:'8px'}}>Solicitar Orçamento</a>
</section>
<section style={{padding:'40px 24px'}}>
<h2>Serviços</h2>
<ul>
<li>Câmbios Automáticos</li>
<li>CVT</li>
<li>DSG</li>
<li>PowerShift</li>
<li>Dualogic</li>
<li>Troca de óleo</li>
</ul>
</section>
<footer style={{padding:'24px',background:'#000'}}>
<p>Rua Tiradentes, 782 - Jardim Panorama - Sarandi/PR</p>
<p>WhatsApp: (44) 99803-4786</p>
</footer>
</main>
)}
