
export const metadata={title:'DT28 Câmbios Automáticos'};
export default function RootLayout({children}:{children:React.ReactNode}){
return <html lang="pt-BR"><body style={{margin:0,fontFamily:'Arial'}}>{children}</body></html>
}
