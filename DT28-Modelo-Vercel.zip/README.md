# DT28

Deploy:
1. Envie para GitHub.
2. Importe na Vercel.
3. npm install
4. Deploy.
